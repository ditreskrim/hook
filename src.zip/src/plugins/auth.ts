import fp from 'fastify-plugin';
import fastifyJWT, { JWT } from '@fastify/jwt';
import { FastifyRequest, FastifyReply } from 'fastify';
import { fastifyCookie } from '@fastify/cookie';
import { User } from '@prisma/client';
import path from 'node:path';

declare module '@fastify/jwt' {
  export interface FastifyJWT {
    user: {
      email: string;
      id: string;
      username: string;
    };
  }
}
declare module 'fastify' {
  interface FastifyRequest {
    jwt: JWT;

    authorized(user: User): Promise<string>;

    unauthorized(): Promise<void>;
  }

  export interface FastifyInstance {
    authenticate: any;
  }
}

/**
 * This plugins adds some utilities to handle http errors
 *
 * @see https://github.com/fastify/fastify-sensible
 */
export default fp(
  async function (fastify) {
    const jwt_cookie_name = 'token';
    fastify.register(fastifyCookie, { secret: process.env.COOKIE_SECRET! ?? 'fatify-cookie-secret' });
    fastify.register(fastifyJWT, {
      secret: process.env.SECRET_KEY! ?? 'fatify-jwt-secret',
      cookie: {
        cookieName: jwt_cookie_name,
        // unsigned cookie for now
        signed: false,
      },
      verify: {
        maxAge: 86400 * 2,
      },
      messages: {
        noAuthorizationInCookieMessage: 'You are not authorized to access',
        authorizationTokenExpiredMessage: 'You are not authorized to access',
        authorizationTokenInvalid: 'You are not authorized to access',
        authorizationTokenUntrusted: 'You are not authorized to access',
      },
    });
    fastify.decorate('authenticate', async (request: FastifyRequest, reply: FastifyReply) => {
      return request
        .jwtVerify()
        .then(function (authorized) {
          console.log('authorized', authorized);
        })
        .catch(function (reason: Error) {
          return reply.unauthorized(reason.message);
        });
    });
    fastify.addHook('onRequest', function (req: FastifyRequest, reply: FastifyReply, done) {
      req.authorized = async function (user: User) {
        const { password, ...payload } = user;
        const token = req.jwt.sign(payload, { expiresIn: 86400 * 2 });
        reply.setCookie(jwt_cookie_name, token, {
          // domain: "*",
          path: '/',
          secure: process.env.NODE_ENV !== 'development',
          httpOnly: true,
          sameSite: process.env.NODE_ENV === 'development' ? false : 'none',
          maxAge: 86400 * 2,
        });
        return token;
      };
      req.unauthorized = async function () {
        reply.setCookie(jwt_cookie_name, '', {
          // domain: "*",
          path: '/',
          secure: process.env.NODE_ENV !== 'development',
          httpOnly: true,
          sameSite: process.env.NODE_ENV === 'development' ? false : 'none',
          maxAge: -1,
        });
      };
      done();
    });
    fastify.addHook('preHandler', (req, _reply, next) => {
      req.jwt = fastify.jwt;
      return next();
    });
  },
  { name: path.basename(__filename) }
);
