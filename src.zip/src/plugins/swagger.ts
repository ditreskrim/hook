import fp from 'fastify-plugin';
import fastifySwagger from '@fastify/swagger';
import fastifySwaggerUi from '@fastify/swagger-ui';
import { FastifyDynamicSwaggerOptions } from '@fastify/swagger';
import path from 'node:path';

export const swaggerConfig: FastifyDynamicSwaggerOptions = {
  swagger: {
    info: {
      title: 'RESTful APIs using Fastify',
      description: 'CRUDs using Swagger, Fastify and Prisma',
      version: '0.0.1'
    },
    externalDocs: {
      url: 'https://swagger.io',
      description: 'Find more info here'
    },
    schemes: ['https', 'http'],
    consumes: ['application/json'],
    produces: ['application/json'],
    tags: []
  }
};

export default fp(
  async (fastify) => {
    if (process.env.ENABLE_SWAGGER != 'true') return;
    fastify.register(fastifySwagger, swaggerConfig);
    fastify.register(fastifySwaggerUi, {
      routePrefix: '/docs'
    });
  },
  { name: path.basename(__filename) }
);
