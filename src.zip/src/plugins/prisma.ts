import { PrismaClient } from '@prisma/client';
const paginator = require('prisma-paginate');
import path from 'node:path';

import fp from 'fastify-plugin';
import { PrismaClientModelsPaginate } from 'prisma-paginate/dist/prisma';
export type PrismaWithPaginator = PrismaClient & PrismaClientModelsPaginate;

export interface IDbContext {
  prisma: PrismaWithPaginator;
}

declare module 'fastify' {
  interface FastifyInstance {
    DbContext: IDbContext;
  }
}

export default fp(
  async (fastify) => {
    const prismaClient = new PrismaClient({
      log: ['error'],
    });
    const prisma = paginator(prismaClient);
    fastify.decorate('DbContext', { prisma });
    fastify.addHook('onClose', async (app) => {
      await app.DbContext.prisma.$disconnect();
      return app;
    });
  },
  { name: path.basename(__filename) }
);
