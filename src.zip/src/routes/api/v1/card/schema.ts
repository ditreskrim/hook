import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseCard = {
  number: z.string(),
  type: z.string().optional(),
  expire_month: z.string(),
  expire_year: z.string(),
  cvc: z.string(),
};

const baseCardRequest = {
  id: z.number().int(),
};

const createCardRequest = z.object({
  ...baseCard,
});

const createCardResponse = z.object({
  data: z.object({
    ...baseCardRequest,
    ...baseCard,
  }),
});

const getCardsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getCardsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...baseCardRequest,
      ...baseCard,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getCardRequest = z.object({
  ...baseCardRequest,
});

const getCardResponse = z.object({
  data: z.object({
    ...baseCardRequest,
    ...baseCard,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteCardRequest = z.object({
  ...baseCardRequest,
});

const updateCardRequestParams = z.object({
  ...baseCardRequest,
});

const updateCardRequestBody = z.object({
  ...baseCard,
});

export type CreateCardRequest = z.input<typeof createCardRequest>;
export type CreateCardResponse = z.infer<typeof createCardResponse>;
export type GetCardsRequest = z.infer<typeof getCardsRequest>;
export type GetCardsResponse = z.infer<typeof getCardsResponse>;
export type GetCardRequest = z.input<typeof getCardRequest>;
export type GetCardResponse = z.infer<typeof getCardResponse>;
export type DeleteCardRequest = z.input<typeof deleteCardRequest>;
export type UpdateCardRequestParams = z.infer<typeof updateCardRequestParams>;
export type UpdateCardRequestBody = z.infer<typeof updateCardRequestBody>;

export const { schemas: cardSchemas, $ref } = buildJsonSchemas(
  {
    createCardRequest,
    createCardResponse,
    getCardRequest,
    getCardsRequest,
    getCardsResponse,
    getCardResponse,
    deleteCardRequest,
    updateCardRequestParams,
    updateCardRequestBody,
  },
  {
    $id: 'cardSchemas',
  }
);
