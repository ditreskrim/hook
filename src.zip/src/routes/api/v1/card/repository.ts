import { CreateCardRequest } from './schema';
import { Card, PrismaClient } from '@prisma/client';

export interface CardRepository {
  create(params: CreateCardRequest): Promise<Card>;

  insert(params: CreateCardRequest): Promise<Card>;
}

export class PrismaCardRepository implements CardRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateCardRequest): Promise<Card> {
    return this.client.card.create({ data: params });
  }
  insert(params: CreateCardRequest): Promise<Card> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.card
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.card
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.card
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
