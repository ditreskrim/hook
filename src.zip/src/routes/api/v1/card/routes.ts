import type { FastifyInstance } from 'fastify';
import { CardCreate, Cardfind } from './controller';
import { $ref, cardSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  cardSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createCardRequest'),
        response: {
          201: $ref('createCardResponse'),
        },
      },
    },
    CardCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getCardResponse'),
        },
      },
    },
    Cardfind
  );
  next();
};
