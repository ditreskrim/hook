import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateCardRequest, GetCardRequest } from './schema';
import { PrismaCardRepository } from './repository';

export async function CardCreate(request: FastifyRequest<{ Body: CreateCardRequest }>, reply: FastifyReply) {
  const repository = new PrismaCardRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Cardfind(request: FastifyRequest<{ Params: GetCardRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.card
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
