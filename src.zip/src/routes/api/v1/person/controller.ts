import { FastifyReply, FastifyRequest } from 'fastify';
import { CreatePersonRequest, GetPersonRequest } from './schema';
import { PrismaPersonRepository } from './repository';

export async function PersonCreate(request: FastifyRequest<{ Body: CreatePersonRequest }>, reply: FastifyReply) {
  const repository = new PrismaPersonRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Personfind(request: FastifyRequest<{ Params: GetPersonRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.person
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
