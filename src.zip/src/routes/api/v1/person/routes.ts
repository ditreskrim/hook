import type { FastifyInstance } from 'fastify';
import { PersonCreate, Personfind } from './controller';
import { $ref, personSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  personSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createPersonRequest'),
        response: {
          201: $ref('createPersonResponse'),
        },
      },
    },
    PersonCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getPersonResponse'),
        },
      },
    },
    Personfind
  );
  next();
};
