import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const basePerson = {
  firstname: z.string(),
  middlename: z.string().optional(),
  lastname: z.string(),
  dob: z.string().optional(),
};

const basePersonRequest = {
  id: z.number().int(),
};

const createPersonRequest = z.object({
  ...basePerson,
});

const createPersonResponse = z.object({
  data: z.object({
    ...basePersonRequest,
    ...basePerson,
  }),
});

const getPersonsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getPersonsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...basePersonRequest,
      ...basePerson,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getPersonRequest = z.object({
  ...basePersonRequest,
});

const getPersonResponse = z.object({
  data: z.object({
    ...basePersonRequest,
    ...basePerson,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deletePersonRequest = z.object({
  ...basePersonRequest,
});

const updatePersonRequestParams = z.object({
  ...basePersonRequest,
});

const updatePersonRequestBody = z.object({
  ...basePerson,
});

export type CreatePersonRequest = z.input<typeof createPersonRequest>;
export type CreatePersonResponse = z.infer<typeof createPersonResponse>;
export type GetPersonsRequest = z.infer<typeof getPersonsRequest>;
export type GetPersonsResponse = z.infer<typeof getPersonsResponse>;
export type GetPersonRequest = z.input<typeof getPersonRequest>;
export type GetPersonResponse = z.infer<typeof getPersonResponse>;
export type DeletePersonRequest = z.input<typeof deletePersonRequest>;
export type UpdatePersonRequestParams = z.infer<typeof updatePersonRequestParams>;
export type UpdatePersonRequestBody = z.infer<typeof updatePersonRequestBody>;

export const { schemas: personSchemas, $ref } = buildJsonSchemas(
  {
    createPersonRequest,
    createPersonResponse,
    getPersonRequest,
    getPersonsRequest,
    getPersonsResponse,
    getPersonResponse,
    deletePersonRequest,
    updatePersonRequestParams,
    updatePersonRequestBody,
  },
  {
    $id: 'personSchemas',
  }
);
