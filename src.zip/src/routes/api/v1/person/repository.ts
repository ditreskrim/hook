import { CreatePersonRequest } from './schema';
import { Person, PrismaClient } from '@prisma/client';

export interface PersonRepository {
  create(params: CreatePersonRequest): Promise<Person>;

  insert(params: CreatePersonRequest): Promise<Person>;
}

export class PrismaPersonRepository implements PersonRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreatePersonRequest): Promise<Person> {
    return this.client.person.create({ data: params });
  }
  insert(params: CreatePersonRequest): Promise<Person> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.person
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.person
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.person
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
