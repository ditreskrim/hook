import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateEmailRequest, GetEmailRequest } from './schema';
import { PrismaEmailRepository } from './repository';

export async function EmailCreate(request: FastifyRequest<{ Body: CreateEmailRequest }>, reply: FastifyReply) {
  const repository = new PrismaEmailRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Emailfind(request: FastifyRequest<{ Params: GetEmailRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.email
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
