import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseEmail = {
  address: z.string().email(),
};

const baseEmailRequest = {
  id: z.number().int(),
};

const createEmailRequest = z.object({
  ...baseEmail,
});

const createEmailResponse = z.object({
  data: z.object({
    ...baseEmailRequest,
    ...baseEmail,
  }),
});

const getEmailsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getEmailsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...baseEmailRequest,
      ...baseEmail,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getEmailRequest = z.object({
  ...baseEmailRequest,
});

const getEmailResponse = z.object({
  data: z.object({
    ...baseEmailRequest,
    ...baseEmail,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteEmailRequest = z.object({
  ...baseEmailRequest,
});

const updateEmailRequestParams = z.object({
  ...baseEmailRequest,
});

const updateEmailRequestBody = z.object({
  ...baseEmail,
});

export type CreateEmailRequest = z.input<typeof createEmailRequest>;
export type CreateEmailResponse = z.infer<typeof createEmailResponse>;
export type GetEmailsRequest = z.infer<typeof getEmailsRequest>;
export type GetEmailsResponse = z.infer<typeof getEmailsResponse>;
export type GetEmailRequest = z.input<typeof getEmailRequest>;
export type GetEmailResponse = z.infer<typeof getEmailResponse>;
export type DeleteEmailRequest = z.input<typeof deleteEmailRequest>;
export type UpdateEmailRequestParams = z.infer<typeof updateEmailRequestParams>;
export type UpdateEmailRequestBody = z.infer<typeof updateEmailRequestBody>;

export const { schemas: emailSchemas, $ref } = buildJsonSchemas(
  {
    createEmailRequest,
    createEmailResponse,
    getEmailRequest,
    getEmailsRequest,
    getEmailsResponse,
    getEmailResponse,
    deleteEmailRequest,
    updateEmailRequestParams,
    updateEmailRequestBody,
  },
  {
    $id: 'emailSchemas',
  }
);
