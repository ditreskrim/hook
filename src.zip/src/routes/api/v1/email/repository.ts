import { CreateEmailRequest } from './schema';
import { Email, PrismaClient } from '@prisma/client';

export interface EmailRepository {
  create(params: CreateEmailRequest): Promise<Email>;

  insert(params: CreateEmailRequest): Promise<Email>;
}

export class PrismaEmailRepository implements EmailRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateEmailRequest): Promise<Email> {
    return this.client.email.create({ data: params });
  }
  insert(params: CreateEmailRequest): Promise<Email> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.email
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.email
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.email
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
