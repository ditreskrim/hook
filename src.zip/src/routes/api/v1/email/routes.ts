import type { FastifyInstance } from 'fastify';
import { EmailCreate, Emailfind } from './controller';
import { $ref, emailSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  emailSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createEmailRequest'),
        response: {
          201: $ref('createEmailResponse'),
        },
      },
    },
    EmailCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getEmailResponse'),
        },
      },
    },
    Emailfind
  );
  next();
};
