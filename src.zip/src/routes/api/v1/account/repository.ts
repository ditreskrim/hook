import { CreateAccountRequest } from './schema';
import { Account, PrismaClient } from '@prisma/client';

export interface AccountRepository {
  create(params: CreateAccountRequest): Promise<Account>;

  insert(params: CreateAccountRequest): Promise<Account>;
}

export class PrismaAccountRepository implements AccountRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateAccountRequest): Promise<Account> {
    return this.client.account.create({ data: params });
  }
  insert(params: CreateAccountRequest): Promise<Account> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.account
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.account
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.account
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
