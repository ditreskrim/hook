import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseAccount = {
  url: z.string().url(),
  username: z.string(),
};

const baseAccountRequest = {
  id: z.number().int(),
};

const createAccountRequest = z.object({
  ...baseAccount,
});

const createAccountResponse = z.object({
  data: z.object({
    ...baseAccountRequest,
    ...baseAccount,
  }),
});

const getAccountsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(25),
});

const getAccountsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...baseAccountRequest,
      ...baseAccount,
      // created_at: z.date(),
      // updated_at: z.date(),
      // deleted_at: z.date(),
    })
  ),
});

const getAccountRequest = z.object({
  ...baseAccountRequest,
});

const getAccountResponse = z.object({
  data: z.object({
    ...baseAccountRequest,
    ...baseAccount,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteAccountRequest = z.object({
  ...baseAccountRequest,
});

const updateAccountRequestParams = z.object({
  ...baseAccountRequest,
});

const updateAccountRequestBody = z.object({
  ...baseAccount,
});

export type CreateAccountRequest = z.input<typeof createAccountRequest>;
export type CreateAccountResponse = z.infer<typeof createAccountResponse>;
export type GetAccountsRequest = z.infer<typeof getAccountsRequest>;
export type GetAccountsResponse = z.infer<typeof getAccountsResponse>;
export type GetAccountRequest = z.input<typeof getAccountRequest>;
export type GetAccountResponse = z.infer<typeof getAccountResponse>;
export type DeleteAccountRequest = z.input<typeof deleteAccountRequest>;
export type UpdateAccountRequestParams = z.infer<typeof updateAccountRequestParams>;
export type UpdateAccountRequestBody = z.infer<typeof updateAccountRequestBody>;

export const { schemas: accountSchemas, $ref } = buildJsonSchemas(
  {
    createAccountRequest,
    createAccountResponse,
    getAccountRequest,
    getAccountsRequest,
    getAccountsResponse,
    getAccountResponse,
    deleteAccountRequest,
    updateAccountRequestParams,
    updateAccountRequestBody,
  },
  {
    $id: 'accountSchemas',
  }
);
