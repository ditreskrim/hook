import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateAccountRequest, GetAccountRequest, GetAccountsRequest } from './schema';
import { PrismaAccountRepository } from './repository';

export async function AccountCreate(request: FastifyRequest<{ Body: CreateAccountRequest }>, reply: FastifyReply) {
  const repository = new PrismaAccountRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
export async function Accountfind(request: FastifyRequest<{ Params: GetAccountRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.account
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err: Error) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function AccountAll(request: FastifyRequest<{ Params: GetAccountsRequest }>, reply: FastifyReply) {
  const { page, limit } = request.params;
  return request.server.DbContext.prisma.account
    .paginate({ where: {} }, { limit: limit, page: page })
    .then(function (found) {
      return reply.code(200).send({
        page: page,
        limit: limit,
        totalRows: found.count,
        totalPages: found.totalPages,
        data: found.result,
      });
    })
    .catch(function (reason: Error) {
      console.error(reason);
      return reply.internalServerError();
    });
}
