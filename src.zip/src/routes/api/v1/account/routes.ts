import type { FastifyInstance } from 'fastify';
import { AccountAll, AccountCreate, Accountfind } from './controller';
import { $ref, accountSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  accountSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createAccountRequest'),
        response: {
          201: $ref('createAccountResponse'),
        },
      },
    },
    AccountCreate
  );
  fastify.get(
    '/',
    {
      schema: {
        params: {
          type: 'object',
          properties: {
            page: {
              type: 'number',
              default: 1,
              description: 'the unique identifier',
            },
            limit: {
              type: 'number',
              default: 10,
              description: 'the unique identifier',
            },
          },
        },
        response: {
          200: $ref('getAccountsResponse'),
        },
      },
    },
    AccountAll
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getAccountResponse'),
        },
      },
    },
    Accountfind
  );
  next();
};
