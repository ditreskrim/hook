import { CreateInsertRequest } from './schema';
import { Person, Prisma, PrismaClient } from '@prisma/client';

export interface InsertRepository {
  insert(params: CreateInsertRequest): Promise<Person>;
}

export class PrismaInsertRepository implements InsertRepository {
  protected includes = {
    gender: true,
    contacts: true,
    cards: true,
    documents: true,
    accounts: true,
    passwords: true,
    browsers: true,
    emails: true,
    phones: true,
    banks: true,
  };

  constructor(private readonly client: PrismaClient) {}

  async insert(params: CreateInsertRequest): Promise<Person> {
    const {
      firstname,
      lastname,
      middlename,
      gender,
      phone,
      password,
      email,
      address1,
      address2,
      city,
      state,
      zip,
      country,
    } = params;
    return this.client.person
      .findFirst({ where: { AND: [{ firstname: firstname }, { lastname: lastname }, { middlename: middlename }] } })
      .then(async (o) => {
        if (o?.id)
          return this.client.person
            .update({
              where: { id: o.id },
              include: this.includes,
              data: {
                firstname: firstname,
                middlename: middlename,
                lastname: lastname,
                gender: gender
                  ? await new Promise<Prisma.PersonGendersCreateNestedOneWithoutPersonInput>(async (resolve) => {
                      const exist = await this.client.gender.findFirst({
                        where: { type: gender },
                      });
                      return resolve(
                        exist?.id
                          ? {
                              connectOrCreate: {
                                where: { person_id_gender_id: { person_id: o.id, gender_id: exist.id } },
                                create: {
                                  gender: {
                                    connectOrCreate: {
                                      where: {
                                        id: exist.id,
                                      },
                                      create: {
                                        type: gender,
                                      },
                                    },
                                  },
                                },
                              },
                            }
                          : {
                              connectOrCreate: {
                                where: { person_id: o.id },
                                create: {
                                  gender: {
                                    create: {
                                      type: gender,
                                    },
                                  },
                                },
                              },
                            }
                      );
                    })
                  : {},
                emails: email
                  ? await new Promise<Prisma.EmailUpdateManyWithoutPersonsNestedInput>(async (resolve) => {
                      return resolve({
                        connectOrCreate: {
                          where: {
                            address: email,
                          },
                          create: {
                            address: email,
                            passwords: password
                              ? {
                                  connectOrCreate: {
                                    where: {
                                      password: password,
                                    },
                                    create: { password: password },
                                  },
                                }
                              : {},
                          },
                        },
                      });
                    })
                  : {},
                passwords: password
                  ? await new Promise<Prisma.PasswordUncheckedUpdateManyWithoutPersonsNestedInput>(async (resolve) => {
                      return resolve({
                        connectOrCreate: {
                          where: {
                            password: password,
                          },
                          create: {
                            password: password,
                            emails: email
                              ? {
                                  connectOrCreate: {
                                    where: { address: email },
                                    create: {
                                      address: email,
                                    },
                                  },
                                }
                              : {},
                          },
                        },
                      });
                    })
                  : {},
                contacts: address1
                  ? await new Promise<Prisma.ContactUncheckedUpdateManyWithoutPersonsNestedInput>(async (resolve) => {
                      const payload = {
                        address1: address1,
                        address2: address2,
                        city: city,
                        state: state,
                        zip: zip,
                        country: country,
                      };
                      const exist = await this.client.contact.findFirst({
                        where: payload,
                      });
                      return resolve(
                        exist?.id
                          ? {
                              connectOrCreate: {
                                where: {
                                  id: exist?.id,
                                },
                                create: payload,
                              },
                            }
                          : {
                              create: payload,
                            }
                      );
                    })
                  : {},
              },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.person
          .create({
            include: this.includes,
            data: {
              firstname: firstname,
              middlename: middlename,
              lastname: lastname,
              gender: gender
                ? await new Promise<Prisma.PersonGendersCreateNestedOneWithoutPersonInput>(async (resolve) => {
                    const exist = await this.client.gender.findFirst({
                      where: { type: gender },
                    });
                    return resolve(
                      exist?.id
                        ? {
                            connectOrCreate: {
                              where: { gender_id: exist.id },
                              create: {
                                gender: {
                                  connectOrCreate: {
                                    where: {
                                      id: exist.id,
                                    },
                                    create: {
                                      type: gender,
                                    },
                                  },
                                },
                              },
                            },
                          }
                        : {
                            create: {
                              gender: {
                                create: {
                                  type: gender,
                                },
                              },
                            },
                          }
                    );
                  })
                : {},
              phones: phone
                ? await new Promise<Prisma.PhoneCreateNestedManyWithoutPersonsInput>((resolve) => {
                    return resolve({
                      connectOrCreate: { where: { number: phone }, create: { number: phone } },
                    });
                  })
                : {},
              emails: email
                ? await new Promise<Prisma.EmailCreateNestedManyWithoutPersonsInput>(async (resolve) => {
                    return resolve({
                      connectOrCreate: {
                        where: {
                          address: email,
                        },
                        create: {
                          address: email,
                          passwords: password
                            ? {
                                connectOrCreate: {
                                  where: {
                                    password: password,
                                  },
                                  create: { password: password },
                                },
                              }
                            : {},
                        },
                      },
                    });
                  })
                : {},
              passwords: password
                ? await new Promise<Prisma.PasswordCreateNestedManyWithoutPersonsInput>(async (resolve) => {
                    return resolve({
                      connectOrCreate: {
                        where: { password: password },
                        create: {
                          password: password,
                          emails: email
                            ? {
                                connectOrCreate: {
                                  where: {
                                    address: email,
                                  },
                                  create: { address: email },
                                },
                              }
                            : {},
                        },
                      },
                    });
                  })
                : {},
            },
          })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
