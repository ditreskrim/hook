import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateInsertRequest } from './schema';
import { PrismaInsertRepository } from './repository';

export async function InsertCreate(request: FastifyRequest<{ Body: CreateInsertRequest }>, reply: FastifyReply) {
  const repository = new PrismaInsertRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
