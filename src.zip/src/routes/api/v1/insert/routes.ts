import type { FastifyInstance } from 'fastify';
import { InsertCreate } from './controller';
import { $ref, insertSchemas } from './schema';
export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  insertSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createInsertRequest'),
        response: {
          201: $ref('createInsertResponse'),
        },
      },
    },
    InsertCreate
  );

  next();
};
