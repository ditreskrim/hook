import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseInsert = {
  firstname: z.string().nonempty(),
  middlename: z.string().optional(),
  lastname: z.string().nonempty(),
  dob: z.string().nonempty().optional(),
  //gender
  gender: z.string().nonempty().optional(),
  //contact
  address1: z.string().optional(),
  address2: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip: z.string().optional(),
  country: z.string().optional(),
  //Phone
  phone: z.string().optional(),
  password: z.string().optional(),
  //Email
  email: z.string().optional(),
  //Browser
  os: z.string().optional(),
  ip: z.string().optional(),
  useragent: z.string().optional(),
};

const baseInsertRequest = {
  id: z.number().int(),
};

const createInsertRequest = z.object({
  ...baseInsert,
});

const createInsertResponse = z.object({
  data: z.object({
    ...baseInsertRequest,
    ...baseInsert,
  }),
});

const getInsertRequest = z.object({
  ...baseInsertRequest,
});

const getInsertResponse = z.object({
  data: z.object({
    ...baseInsertRequest,
    ...baseInsert,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteInsertRequest = z.object({
  ...baseInsertRequest,
});

const updateInsertRequestParams = z.object({
  ...baseInsertRequest,
});

const updateInsertRequestBody = z.object({
  ...baseInsert,
});

export type CreateInsertRequest = z.input<typeof createInsertRequest>;
export type CreateInsertResponse = z.infer<typeof createInsertResponse>;

export type GetInsertRequest = z.input<typeof getInsertRequest>;
export type GetInsertResponse = z.infer<typeof getInsertResponse>;
export type DeleteInsertRequest = z.input<typeof deleteInsertRequest>;
export type UpdateInsertRequestParams = z.infer<typeof updateInsertRequestParams>;
export type UpdateInsertRequestBody = z.infer<typeof updateInsertRequestBody>;

export const { schemas: insertSchemas, $ref } = buildJsonSchemas(
  {
    createInsertRequest,
    createInsertResponse,
    getInsertRequest,
    getInsertResponse,
    deleteInsertRequest,
    updateInsertRequestParams,
    updateInsertRequestBody,
  },
  {
    $id: 'insertSchemas',
  }
);
