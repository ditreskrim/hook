import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateUserRequest, LoginUserInput } from './schema';
import { hashPassword, verifyPassword } from '../../../../helpers/hash';

export const registerUserHandler = async (
  request: FastifyRequest<{ Body: CreateUserRequest }>,
  reply: FastifyReply
) => {
  const { email, password, username } = request.body;
  return request.server.DbContext.prisma.user
    .findFirst({ where: { OR: [{ email: email }, { username: username }] } })
    .then(async function (u) {
      if (u?.id) return reply.notAcceptable('User already exists');
      const { hash, salt } = hashPassword(password);
      return await request.server.DbContext.prisma.user
        .create({
          data: {
            email: email,
            username: username,
            password: hash,
            salt: salt,
          },
        })
        .then(function (user) {
          return reply.code(201).send(user);
        })
        .catch(function (reason) {
          console.error(reason);
          return reply.internalServerError();
        });
    })
    .catch(function (reason) {
      console.error(reason);
      return reply.internalServerError();
    });
};
export const loginHandler = async (request: FastifyRequest<{ Body: LoginUserInput }>, reply: FastifyReply) => {
  const { email, password: pwd } = request.body;
  return request.server.DbContext.prisma.user
    .findFirst({ where: { email: email } })
    .then(async function (u) {
      if (
        u?.id &&
        verifyPassword({
          passwd: pwd,
          salt: u.salt,
          hash: u.password,
        })
      ) {
        return request
          .authorized(u)
          .then(function (token) {
            return reply.code(200).send({ token: token });
          })
          .catch(function (reason) {
            console.error(reason);
            return reply.internalServerError();
          });
      }
      return reply.unauthorized();
    })
    .catch(function (reason) {
      console.error(reason);
      return reply.internalServerError();
    });
};
export const getUsersHandler = async (request: FastifyRequest, reply: FastifyReply) => {
  return request.server.DbContext.prisma.user
    .findMany({
      select: {
        email: true,
        username: true,
        id: true,
      },
    })
    .then(async function (u) {
      return reply.code(200).send(u);
    })
    .catch(function (reason) {
      console.error(reason);
      return reply.internalServerError();
    });
};
export const getUserHandler = async (request: FastifyRequest, reply: FastifyReply) => {
  const { email } = request.user;
  return request.server.DbContext.prisma.user
    .findFirstOrThrow({ where: { email: email } })
    .then(async function (u) {
      return reply.code(200).send(u);
    })
    .catch(() => reply.unauthorized());
};
export const userLogoutHandler = async (request: FastifyRequest, reply: FastifyReply) => {
  return request
    .unauthorized()
    .then(function () {
      return reply.code(200).send();
    })
    .catch(() => reply.internalServerError());
};
