import { CreateUserRequest } from './schema';
import { PrismaClient, User } from '@prisma/client';
import { hashPassword } from '../../../../helpers/hash';

export interface UserRepository {
  create(params: CreateUserRequest): Promise<User>;

  insert(params: CreateUserRequest): Promise<User>;
}

export class PrismaUserRepository implements UserRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateUserRequest): Promise<User> {
    const { password, ...payload } = params;
    const { hash, salt } = hashPassword(password);
    return this.client.user.create({
      data: {
        password: hash,
        salt: salt,
        ...payload,
      },
    });
  }

  insert(params: CreateUserRequest): Promise<User> {
    const { password, ...payload } = params;
    const where = Array.from(Object.entries(payload)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.user
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.user
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        const { password, ...payload } = params;
        const { hash, salt } = hashPassword(password);
        return this.client.user
          .create({
            data: {
              password: hash,
              salt: salt,
              ...payload,
            },
          })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
