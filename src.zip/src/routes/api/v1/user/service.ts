import { CreateUserRequest } from './schema';
import { PrismaClient } from '@prisma/client';
import { hashPassword } from '../../../../helpers/hash';

export const findUserByEmail = async (client: PrismaClient, email: string) => {
  console.log('client', client);
  const user = await client.user.findUnique({
    where: {
      email,
    },
  });

  return user;
};

export const createUser = async (client: PrismaClient, user: CreateUserRequest) => {
  const { hash, salt } = hashPassword(user.password);

  const userExists = await findUserByEmail(client, user.email);

  if (userExists) {
    throw { message: 'User with same email already exists' };
  }

  return client.user.create({
    data: {
      ...user,
      password: hash,
      salt: salt,
    },
  });
};

export const getAllUsers = async (client: PrismaClient) => {
  return client.user.findMany({
    select: {
      email: true,
      username: true,
      id: true,
    },
  });
};
