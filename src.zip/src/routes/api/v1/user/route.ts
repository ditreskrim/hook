import { FastifyInstance } from 'fastify';
import { getUserHandler, getUsersHandler, loginHandler, registerUserHandler, userLogoutHandler } from './controller';
import { userSchemas, $ref } from './schema';

export default async function userRoutes(fastify: FastifyInstance) {
  userSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createUserSchema'),
        response: { 201: $ref('createUserResponseSchema') },
      },
    },
    registerUserHandler
  );
  fastify.post(
    '/login',
    {
      schema: {
        body: $ref('loginSchema'),
        response: {
          200: $ref('loginResponseSchema'),
        },
      },
    },
    loginHandler
  );
  fastify.get('/logout', {}, userLogoutHandler);
  fastify.get('/whoami', { preHandler: [fastify.authenticate] }, getUserHandler);
  fastify.get(
    '/',
    {
      preHandler: fastify.authenticate,
    },
    getUsersHandler
  );
}
