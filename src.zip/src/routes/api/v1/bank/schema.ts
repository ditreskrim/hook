import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseBank = {
  number: z.string(),
  name: z.string().optional(),
  country: z.string().optional(),
};

const baseBankRequest = {
  id: z.number().int(),
};

const createBankRequest = z.object({
  ...baseBank,
});

const createBankResponse = z.object({
  bank: z.object({
    ...baseBankRequest,
    ...baseBank,
  }),
});

const getBanksRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getBanksResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...baseBankRequest,
      ...baseBank,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getBankRequest = z.object({
  ...baseBankRequest,
});

const getBankResponse = z.object({
  data: z.object({
    ...baseBankRequest,
    ...baseBank,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteBankRequest = z.object({
  ...baseBankRequest,
});

const updateBankRequestParams = z.object({
  ...baseBankRequest,
});

const updateBankRequestBody = z.object({
  ...baseBank,
});

export type CreateBankRequest = z.input<typeof createBankRequest>;
export type CreateBankResponse = z.infer<typeof createBankResponse>;
export type GetBanksRequest = z.infer<typeof getBanksRequest>;
export type GetBanksResponse = z.infer<typeof getBanksResponse>;
export type GetBankRequest = z.input<typeof getBankRequest>;
export type GetBankResponse = z.infer<typeof getBankResponse>;
export type DeleteBankRequest = z.input<typeof deleteBankRequest>;
export type UpdateBankRequestParams = z.infer<typeof updateBankRequestParams>;
export type UpdateBankRequestBody = z.infer<typeof updateBankRequestBody>;

export const { schemas: bankSchemas, $ref } = buildJsonSchemas(
  {
    createBankRequest,
    createBankResponse,
    getBankRequest,
    getBanksRequest,
    getBanksResponse,
    getBankResponse,
    deleteBankRequest,
    updateBankRequestParams,
    updateBankRequestBody,
  },
  {
    $id: 'bankSchemas',
  }
);
