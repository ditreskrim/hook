import type { FastifyInstance } from 'fastify';
import { BankCreate, Bankfind } from './controller';
import { $ref, bankSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  bankSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createBankRequest'),
        response: {
          201: $ref('createBankResponse'),
        },
      },
    },
    BankCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getBankResponse'),
        },
      },
    },
    Bankfind
  );
  next();
};
