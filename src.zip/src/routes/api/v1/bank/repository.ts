import { CreateBankRequest } from './schema';
import { Bank, PrismaClient } from '@prisma/client';

export interface BankRepository {
  create(params: CreateBankRequest): Promise<Bank>;

  insert(params: CreateBankRequest): Promise<Bank>;
}

export class PrismaBankRepository implements BankRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateBankRequest): Promise<Bank> {
    return this.client.bank.create({ data: params });
  }
  insert(params: CreateBankRequest): Promise<Bank> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.bank
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.bank
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.bank
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
