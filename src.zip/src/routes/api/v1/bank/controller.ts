import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateBankRequest, GetBankRequest } from './schema';
import { PrismaBankRepository } from './repository';

export async function BankCreate(request: FastifyRequest<{ Body: CreateBankRequest }>, reply: FastifyReply) {
  const repository = new PrismaBankRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Bankfind(request: FastifyRequest<{ Params: GetBankRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.bank
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
