import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseContact = {
  address1: z.string().optional(),
  address2: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip: z.string().optional(),
  country: z.string().optional(),
};

const baseContactRequest = {
  id: z.number().int(),
};

const createContactRequest = z.object({
  ...baseContact,
});

const createContactResponse = z.object({
  contact: z.object({
    ...baseContactRequest,
    ...baseContact,
  }),
});

const getContactsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getContactsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  contact: z.array(
    z.object({
      ...baseContactRequest,
      ...baseContact,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getContactRequest = z.object({
  ...baseContactRequest,
});

const getContactResponse = z.object({
  contact: z.object({
    ...baseContactRequest,
    ...baseContact,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteContactRequest = z.object({
  ...baseContactRequest,
});

const updateContactRequestParams = z.object({
  ...baseContactRequest,
});

const updateContactRequestBody = z.object({
  ...baseContact,
});

export type CreateContactRequest = z.input<typeof createContactRequest>;
export type CreateContactResponse = z.infer<typeof createContactResponse>;
export type GetContactsRequest = z.infer<typeof getContactsRequest>;
export type GetContactsResponse = z.infer<typeof getContactsResponse>;
export type GetContactRequest = z.input<typeof getContactRequest>;
export type GetContactResponse = z.infer<typeof getContactResponse>;
export type DeleteContactRequest = z.input<typeof deleteContactRequest>;
export type UpdateContactRequestParams = z.infer<typeof updateContactRequestParams>;
export type UpdateContactRequestBody = z.infer<typeof updateContactRequestBody>;

export const { schemas: contactSchemas, $ref } = buildJsonSchemas(
  {
    createContactRequest,
    createContactResponse,
    getContactRequest,
    getContactsRequest,
    getContactsResponse,
    getContactResponse,
    deleteContactRequest,
    updateContactRequestParams,
    updateContactRequestBody,
  },
  {
    $id: 'contactSchemas',
  }
);
