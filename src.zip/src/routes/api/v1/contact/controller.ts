import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateContactRequest, GetContactRequest } from './schema';
import { PrismaContactRepository } from './repository';

export async function ContactCreate(request: FastifyRequest<{ Body: CreateContactRequest }>, reply: FastifyReply) {
  const repository = new PrismaContactRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Contactfind(request: FastifyRequest<{ Params: GetContactRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.contact
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
