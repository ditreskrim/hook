import type { FastifyInstance } from 'fastify';
import { ContactCreate, Contactfind } from './controller';
import { $ref, contactSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  contactSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createContactRequest'),
        response: {
          201: $ref('createContactResponse'),
        },
      },
    },
    ContactCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getContactResponse'),
        },
      },
    },
    Contactfind
  );
  next();
};
