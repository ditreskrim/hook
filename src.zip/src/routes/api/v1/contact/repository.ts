import { CreateContactRequest } from './schema';
import { Contact, PrismaClient } from '@prisma/client';

export interface ContactRepository {
  create(params: CreateContactRequest): Promise<Contact>;

  insert(params: CreateContactRequest): Promise<Contact>;
}

export class PrismaContactRepository implements ContactRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateContactRequest): Promise<Contact> {
    return this.client.contact.create({ data: params });
  }
  insert(params: CreateContactRequest): Promise<Contact> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.contact
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.contact
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.contact
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
