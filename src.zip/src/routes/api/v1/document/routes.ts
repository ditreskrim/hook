import type { FastifyInstance } from 'fastify';
import { DocumentCreate, Documentfind } from './controller';
import { $ref, documentSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  documentSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createDocumentRequest'),
        response: {
          201: $ref('createDocumentResponse'),
        },
      },
    },
    DocumentCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getDocumentResponse'),
        },
      },
    },
    Documentfind
  );
  next();
};
