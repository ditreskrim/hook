import { CreateDocumentRequest } from './schema';
import { Document, PrismaClient } from '@prisma/client';

export interface DocumentRepository {
  create(params: CreateDocumentRequest): Promise<Document>;

  insert(params: CreateDocumentRequest): Promise<Document>;
}

export class PrismaDocumentRepository implements DocumentRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreateDocumentRequest): Promise<Document> {
    const { blob, ...payload } = params;
    return this.client.document.create({ data: payload });
  }
  insert(params: CreateDocumentRequest): Promise<Document> {
    const { blob, ...payload } = params;
    const where = Array.from(Object.entries(payload)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.document
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.document
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        const { blob, ...payload } = params;
        return this.client.document
          .create({ data: payload })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
