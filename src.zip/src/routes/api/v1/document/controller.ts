import { FastifyReply, FastifyRequest } from 'fastify';
import { CreateDocumentRequest, GetDocumentRequest } from './schema';
import { PrismaDocumentRepository } from './repository';

export async function DocumentCreate(request: FastifyRequest<{ Body: CreateDocumentRequest }>, reply: FastifyReply) {
  const repository = new PrismaDocumentRepository(request.server.DbContext.prisma);
  return repository
    .insert(request.body)
    .then((o) => reply.code(200).send(o))
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}

export async function Documentfind(request: FastifyRequest<{ Params: GetDocumentRequest }>, reply: FastifyReply) {
  const { id } = request.params;
  return request.server.DbContext.prisma.document
    .findFirst({
      where: { id: Number(id) },
    })
    .then(async function (o) {
      if (!o?.id) return reply.notFound();
      return reply.code(200).send(o);
    })
    .catch(function (err) {
      console.error(err);
      return reply.internalServerError();
    });
}
