import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const baseDocument = {
  number: z.string(),
  type: z.string(),
  country: z.string().optional(),
  expire: z.string().optional(),
  blob: z.unknown().optional(),
};

const baseDocumentRequest = {
  id: z.number().int(),
};

const createDocumentRequest = z.object({
  ...baseDocument,
});

const createDocumentResponse = z.object({
  data: z.object({
    ...baseDocumentRequest,
    ...baseDocument,
  }),
});

const getDocumentsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getDocumentsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...baseDocumentRequest,
      ...baseDocument,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getDocumentRequest = z.object({
  ...baseDocumentRequest,
});

const getDocumentResponse = z.object({
  data: z.object({
    ...baseDocumentRequest,
    ...baseDocument,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deleteDocumentRequest = z.object({
  ...baseDocumentRequest,
});

const updateDocumentRequestParams = z.object({
  ...baseDocumentRequest,
});

const updateDocumentRequestBody = z.object({
  ...baseDocument,
});

export type CreateDocumentRequest = z.input<typeof createDocumentRequest>;
export type CreateDocumentResponse = z.infer<typeof createDocumentResponse>;
export type GetDocumentsRequest = z.infer<typeof getDocumentsRequest>;
export type GetDocumentsResponse = z.infer<typeof getDocumentsResponse>;
export type GetDocumentRequest = z.input<typeof getDocumentRequest>;
export type GetDocumentResponse = z.infer<typeof getDocumentResponse>;
export type DeleteDocumentRequest = z.input<typeof deleteDocumentRequest>;
export type UpdateDocumentRequestParams = z.infer<typeof updateDocumentRequestParams>;
export type UpdateDocumentRequestBody = z.infer<typeof updateDocumentRequestBody>;

export const { schemas: documentSchemas, $ref } = buildJsonSchemas(
  {
    createDocumentRequest,
    createDocumentResponse,
    getDocumentRequest,
    getDocumentsRequest,
    getDocumentsResponse,
    getDocumentResponse,
    deleteDocumentRequest,
    updateDocumentRequestParams,
    updateDocumentRequestBody,
  },
  {
    $id: 'documentSchemas',
  }
);
