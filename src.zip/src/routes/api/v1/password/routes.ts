import type { FastifyInstance } from 'fastify';
import { PasswordCreate, Passwordfind } from './controller';
import { $ref, passwordSchemas } from './schema';
import { identifierSchema } from '../../../../helpers/commons';

export default async (
  fastify: FastifyInstance,
  _opts: Record<never, never>,
  next: (err?: Error | undefined) => void
) => {
  passwordSchemas.map((schema) => fastify.addSchema(schema));
  fastify.post(
    '/',
    {
      schema: {
        body: $ref('createPasswordRequest'),
        response: {
          201: $ref('createPasswordResponse'),
        },
      },
    },
    PasswordCreate
  );
  fastify.get(
    '/:id',
    {
      schema: {
        params: identifierSchema,
        response: {
          201: $ref('getPasswordResponse'),
        },
      },
    },
    Passwordfind
  );
  next();
};
