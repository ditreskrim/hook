import { CreatePasswordRequest } from './schema';
import { Password, PrismaClient } from '@prisma/client';

export interface PasswordRepository {
  create(params: CreatePasswordRequest): Promise<Password>;

  insert(params: CreatePasswordRequest): Promise<Password>;
}

export class PrismaPasswordRepository implements PasswordRepository {
  constructor(private readonly client: PrismaClient) {}

  create(params: CreatePasswordRequest): Promise<Password> {
    return this.client.password.create({ data: params });
  }
  insert(params: CreatePasswordRequest): Promise<Password> {
    const where = Array.from(Object.entries(params)).map(function ([k, v]) {
      return { [k]: v };
    });
    return this.client.password
      .findFirst({ where: { AND: where } })
      .then((o) => {
        if (o?.id)
          return this.client.password
            .update({
              where: { id: o.id },
              data: { updated_at: new Date() },
            })
            .then(function (o) {
              return o;
            })
            .catch(function (reason) {
              throw new Error(reason);
            });
        return this.client.password
          .create({ data: params })
          .then(function (o) {
            return o;
          })
          .catch(function (reason) {
            throw new Error(reason);
          });
      })
      .catch(function (reason) {
        throw new Error(reason);
      });
  }
}
