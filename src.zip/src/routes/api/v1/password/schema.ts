import { z } from 'zod';
import { buildJsonSchemas } from 'fastify-zod';

const basePassword = {
  password: z.string(),
};

const basePasswordRequest = {
  id: z.number().int(),
};

const createPasswordRequest = z.object({
  ...basePassword,
});

const createPasswordResponse = z.object({
  data: z.object({
    ...basePasswordRequest,
    ...basePassword,
  }),
});

const getPasswordsRequest = z.object({
  page: z.number().int().min(1).default(1),
  limit: z.number().int().min(0).default(0),
});

const getPasswordsResponse = z.object({
  page: z.number().int(),
  limit: z.number().int(),
  totalRows: z.number().int(),
  totalPages: z.number().int(),
  data: z.array(
    z.object({
      ...basePasswordRequest,
      ...basePassword,
      created_at: z.date(),
      updated_at: z.date(),
      deleted_at: z.date(),
    })
  ),
});

const getPasswordRequest = z.object({
  ...basePasswordRequest,
});

const getPasswordResponse = z.object({
  data: z.object({
    ...basePasswordRequest,
    ...basePassword,
    created_at: z.date(),
    updated_at: z.date(),
    deleted_at: z.date(),
  }),
});

const deletePasswordRequest = z.object({
  ...basePasswordRequest,
});

const updatePasswordRequestParams = z.object({
  ...basePasswordRequest,
});

const updatePasswordRequestBody = z.object({
  ...basePassword,
});

export type CreatePasswordRequest = z.input<typeof createPasswordRequest>;
export type CreatePasswordResponse = z.infer<typeof createPasswordResponse>;
export type GetPasswordsRequest = z.infer<typeof getPasswordsRequest>;
export type GetPasswordsResponse = z.infer<typeof getPasswordsResponse>;
export type GetPasswordRequest = z.input<typeof getPasswordRequest>;
export type GetPasswordResponse = z.infer<typeof getPasswordResponse>;
export type DeletePasswordRequest = z.input<typeof deletePasswordRequest>;
export type UpdatePasswordRequestParams = z.infer<typeof updatePasswordRequestParams>;
export type UpdatePasswordRequestBody = z.infer<typeof updatePasswordRequestBody>;

export const { schemas: passwordSchemas, $ref } = buildJsonSchemas(
  {
    createPasswordRequest,
    createPasswordResponse,
    getPasswordRequest,
    getPasswordsRequest,
    getPasswordsResponse,
    getPasswordResponse,
    deletePasswordRequest,
    updatePasswordRequestParams,
    updatePasswordRequestBody,
  },
  {
    $id: 'passwordSchemas',
  }
);
